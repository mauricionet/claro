#qpy:console
try:
    from dmenthe1 import FreedomCreative 
except:
    from dmenthe2 import FreedomCreative 

fc = FreedomCreative()
fc.set_config('ffpstutors.ini')
fc.jalankan()